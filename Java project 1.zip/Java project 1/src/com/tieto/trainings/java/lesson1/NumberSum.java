package com.tieto.trainings.java.lesson1;

public class NumberSum {
    public static void main(String[] args) {
        ;
    }
    }
}
